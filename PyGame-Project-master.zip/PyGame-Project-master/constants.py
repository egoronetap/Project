# Egor
SCREEN_WIDTH = 710
SCREEN_HEIGHT = 710

SCREEN_TITLE = 'Супер игра 228'

STAGE = 'Меню'

DB = 'db/scores.db'

STATUS = False
