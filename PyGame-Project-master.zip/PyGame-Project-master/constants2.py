# Anfisa
SIDE = 710
SIZE = WIDTH, HEIGHT = SIDE, SIDE
DB = 'db/scores.db'
